// app.js

const express = require('express');
const http = require('http');
const path = require('path');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');

const app = express();
const server = http.createServer(app);

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const papagoApiUrl = 'https://openapi.naver.com/v1/papago/n2mt';
const naverClientId = 'ycnD3bnqDuEDcN9rcaY0';
const naverClientSecret = '79SAA1A5WB';

app.post('/translate', async (req, res) => {
  const text = req.body.text;

  const headers = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Naver-Client-Id': naverClientId,
    'X-Naver-Client-Secret': naverClientSecret,
  };

  const body = new URLSearchParams({
    source: 'ko',
    target: 'en',
    text,
  });

  try {
    const response = await fetch(papagoApiUrl, { method: 'POST', headers, body });
    const result = await response.json();
    
    res.json({ translatedText: result.message.result.translatedText });
  } catch (error) {
    console.error('Translation error:', error.message);
    res.status(500).json({ error: 'Translation error' });
  }
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
