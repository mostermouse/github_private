module.exports = (io, translate) => {
  io.on('connection', (socket) => {
    console.log('User connected');

    socket.on('message', async (data) => {
      try {
        const translation = await translateMessage(data.original);
        io.emit('message', { original: data.original, translated: translation });
      } catch (error) {
        console.error('Translation error:', error);
        io.emit('message', { original: data.original, translated: 'Translation error' });
      }
    });

    socket.on('disconnect', () => {
      console.log('User disconnected');
    });
  });

  async function translateMessage(message) {
    return new Promise(async (resolve, reject) => {
      try {
        const [translation] = await translate.translate(message, 'ko');
        resolve(translation);
      } catch (error) {
        console.error('Translation error:', error);
        reject(error);
      }
    });
  }
};